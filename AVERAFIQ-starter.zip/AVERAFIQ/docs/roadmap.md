# Roadmap

Plans may change. Dates are intentionally not promised.

## v0.1: Foundation
- Android app shell and theme (light/dark)
- Notes, tasks, reminders (all offline)
- AI chat with user-supplied API key
- Manual, user-controlled memory

## v0.2: Intelligence
- Smarter memory and search
- Voice input

## v0.3: Automation
- Scheduled actions and simple workflows

## v0.4: Life companion
- Study helper, elderly-friendly mode, expense tracker

## v1.0: Public release
- Documentation, privacy policy, Google Play release

## Out of scope for now
- Training our own AI models
- Mandatory accounts or our own cloud
- Automatic SMS or payment execution
